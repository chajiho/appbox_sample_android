package co.kr.appboxtest.appbox_test_and

import android.app.Dialog
import android.content.Context


class LoadingView(context: Context) : Dialog(context) {



    
}